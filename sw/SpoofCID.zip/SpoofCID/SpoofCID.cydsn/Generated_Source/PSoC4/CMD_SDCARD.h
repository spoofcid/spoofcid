/*******************************************************************************
* File Name: CMD_SDCARD.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_CMD_SDCARD_H) /* Pins CMD_SDCARD_H */
#define CY_PINS_CMD_SDCARD_H

#include "cytypes.h"
#include "cyfitter.h"
#include "CMD_SDCARD_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} CMD_SDCARD_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   CMD_SDCARD_Read(void);
void    CMD_SDCARD_Write(uint8 value);
uint8   CMD_SDCARD_ReadDataReg(void);
#if defined(CMD_SDCARD__PC) || (CY_PSOC4_4200L) 
    void    CMD_SDCARD_SetDriveMode(uint8 mode);
#endif
void    CMD_SDCARD_SetInterruptMode(uint16 position, uint16 mode);
uint8   CMD_SDCARD_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void CMD_SDCARD_Sleep(void); 
void CMD_SDCARD_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(CMD_SDCARD__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define CMD_SDCARD_DRIVE_MODE_BITS        (3)
    #define CMD_SDCARD_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - CMD_SDCARD_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the CMD_SDCARD_SetDriveMode() function.
         *  @{
         */
        #define CMD_SDCARD_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define CMD_SDCARD_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define CMD_SDCARD_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define CMD_SDCARD_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define CMD_SDCARD_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define CMD_SDCARD_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define CMD_SDCARD_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define CMD_SDCARD_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define CMD_SDCARD_MASK               CMD_SDCARD__MASK
#define CMD_SDCARD_SHIFT              CMD_SDCARD__SHIFT
#define CMD_SDCARD_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in CMD_SDCARD_SetInterruptMode() function.
     *  @{
     */
        #define CMD_SDCARD_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define CMD_SDCARD_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define CMD_SDCARD_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define CMD_SDCARD_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(CMD_SDCARD__SIO)
    #define CMD_SDCARD_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(CMD_SDCARD__PC) && (CY_PSOC4_4200L)
    #define CMD_SDCARD_USBIO_ENABLE               ((uint32)0x80000000u)
    #define CMD_SDCARD_USBIO_DISABLE              ((uint32)(~CMD_SDCARD_USBIO_ENABLE))
    #define CMD_SDCARD_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define CMD_SDCARD_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define CMD_SDCARD_USBIO_ENTER_SLEEP          ((uint32)((1u << CMD_SDCARD_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << CMD_SDCARD_USBIO_SUSPEND_DEL_SHIFT)))
    #define CMD_SDCARD_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << CMD_SDCARD_USBIO_SUSPEND_SHIFT)))
    #define CMD_SDCARD_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << CMD_SDCARD_USBIO_SUSPEND_DEL_SHIFT)))
    #define CMD_SDCARD_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(CMD_SDCARD__PC)
    /* Port Configuration */
    #define CMD_SDCARD_PC                 (* (reg32 *) CMD_SDCARD__PC)
#endif
/* Pin State */
#define CMD_SDCARD_PS                     (* (reg32 *) CMD_SDCARD__PS)
/* Data Register */
#define CMD_SDCARD_DR                     (* (reg32 *) CMD_SDCARD__DR)
/* Input Buffer Disable Override */
#define CMD_SDCARD_INP_DIS                (* (reg32 *) CMD_SDCARD__PC2)

/* Interrupt configuration Registers */
#define CMD_SDCARD_INTCFG                 (* (reg32 *) CMD_SDCARD__INTCFG)
#define CMD_SDCARD_INTSTAT                (* (reg32 *) CMD_SDCARD__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define CMD_SDCARD_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(CMD_SDCARD__SIO)
    #define CMD_SDCARD_SIO_REG            (* (reg32 *) CMD_SDCARD__SIO)
#endif /* (CMD_SDCARD__SIO_CFG) */

/* USBIO registers */
#if !defined(CMD_SDCARD__PC) && (CY_PSOC4_4200L)
    #define CMD_SDCARD_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define CMD_SDCARD_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define CMD_SDCARD_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define CMD_SDCARD_DRIVE_MODE_SHIFT       (0x00u)
#define CMD_SDCARD_DRIVE_MODE_MASK        (0x07u << CMD_SDCARD_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins CMD_SDCARD_H */


/* [] END OF FILE */

/*******************************************************************************
* File Name: Comp_2.h
* Version 1.20
*
* Description:
*  This file contains the function prototypes and constants used in
*  the Analog Comparator User Module.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_COMPARATOR_Comp_2_H)
#define CY_COMPARATOR_Comp_2_H

#include "cytypes.h"
#include "CyLib.h"
#include "cyfitter.h"


/***************************************
*       Type Definitions
***************************************/

/* Structure to save state before go to sleep */
typedef struct
{
    uint8  enableState;
} Comp_2_BACKUP_STRUCT;


/**************************************
*        Function Prototypes
**************************************/
void    Comp_2_Init(void);
void    Comp_2_Enable(void);
void    Comp_2_Start(void);
void    Comp_2_Stop(void);
void    Comp_2_SetSpeed(uint32 speed);
uint32  Comp_2_ZeroCal(void);
void    Comp_2_LoadTrim(uint32 trimVal);
void    Comp_2_Sleep(void);
void    Comp_2_Wakeup(void);
void    Comp_2_SaveConfig(void);
void    Comp_2_RestoreConfig(void);
uint32  Comp_2_GetCompare(void);
uint32  Comp_2_GetInterruptSource(void);
void    Comp_2_ClearInterrupt(uint32 interruptMask);
void    Comp_2_SetInterrupt(uint32 interruptMask);
void    Comp_2_SetInterruptMask(uint32 interruptMask);
uint32  Comp_2_GetInterruptMask(void);
uint32  Comp_2_GetInterruptSourceMasked(void);
void    Comp_2_SetInterruptMode(uint32 mode);
void    Comp_2_DisableInterruptOutput(void);

#define Comp_2_EnableInterruptOutput(void)     Comp_2_SetInterruptMask(Comp_2_GetInterruptMask() | Comp_2_INTR_MASK)
#define Comp_2_GetInterruptOutputStatus(void)  ((0u == (Comp_2_GetInterruptSourceMasked() & Comp_2_INTR_MASKED)) ? 0u : 1u)
#define Comp_2_ClearInterruptOutput(void)      Comp_2_ClearInterrupt(Comp_2_INTR)
#define Comp_2_SetInterruptOutput(void)        Comp_2_SetInterrupt(Comp_2_INTR_MASK)

/**************************************
*           API Constants
**************************************/

/* Power constants for SetSpeed() function */
#define Comp_2_SLOW_SPEED     (0x01u)
#define Comp_2_MED_SPEED      (0x02u)
#define Comp_2_HIGH_SPEED     (0x03u)

/* Trim defines for ZeroCal() function */
#define Comp_2_COMP_TRIM_SIGN_SHIFT   (5u)
#define Comp_2_COMP_TRIM_MAX_VALUE    (32u)
#define Comp_2_COMP_CALIBRATION_DELAY (10u)

/* Constants for Comp_2_SetInterruptMode(), mode parameter */
#define Comp_2_INTR_DISABLE       (0x00u)
#define Comp_2_INTR_RISING        (0x01u)
#define Comp_2_INTR_FALLING       (0x02u)
#define Comp_2_INTR_BOTH          (0x03u)

/* Constants for Comp_2_GetInterruptSource() and 
* Comp_2_ClearInterrupt(), interruptMask parameter 
*/
#define Comp_2_INTR_SHIFT         (Comp_2_cy_psoc4_abuf__INTR_SHIFT)
#define Comp_2_INTR               ((uint32)0x01u << Comp_2_INTR_SHIFT)

/* Constants for Comp_2_SetInterrupt(), interruptMask parameter */
#define Comp_2_INTR_SET_SHIFT     (Comp_2_cy_psoc4_abuf__INTR_SET_SHIFT)
#define Comp_2_INTR_SET           ((uint32)0x01u << Comp_2_INTR_SHIFT)

/* Constants for Comp_2_GetInterruptMask() and 
* Comp_2_SetInterruptMask(), interruptMask parameter 
*/
#define Comp_2_INTR_MASK_SHIFT    (Comp_2_cy_psoc4_abuf__INTR_MASK_SHIFT)
#define Comp_2_INTR_MASK          ((uint32)0x01u << Comp_2_INTR_MASK_SHIFT)

/* Constants for Comp_2_GetInterruptSourceMasked() */ 
#define Comp_2_INTR_MASKED_SHIFT  (Comp_2_cy_psoc4_abuf__INTR_MASKED_SHIFT)
#define Comp_2_INTR_MASKED        ((uint32)0x01u << Comp_2_INTR_MASKED_SHIFT)


/***************************************
*   Initial Parameter Constants
****************************************/

#define Comp_2_HYSTERESIS         (1u)
#define Comp_2_POWER              (3u)
#define Comp_2_DEEPSLEEP_SUPPORT  (0u)
#define Comp_2_INTERRUPT_EN       (0u)
#define Comp_2_INTERRUPT          (0u)


/***************************************
*    Variables with External Linkage
***************************************/

extern uint8  Comp_2_initVar;


/**************************************
*             Registers
**************************************/

#ifdef CYIPBLOCK_m0s8pass4b_VERSION
    #define Comp_2_CTB_CTRL_REG       (*(reg32 *) Comp_2_cy_psoc4_abuf__CTB_CTB_CTRL)
    #define Comp_2_CTB_CTRL_PTR       ( (reg32 *) Comp_2_cy_psoc4_abuf__CTB_CTB_CTRL)
#else
    #define Comp_2_CTB_CTRL_REG       (*(reg32 *) Comp_2_cy_psoc4_abuf__CTBM_CTB_CTRL)
    #define Comp_2_CTB_CTRL_PTR       ( (reg32 *) Comp_2_cy_psoc4_abuf__CTBM_CTB_CTRL)
#endif /* CYIPBLOCK_m0s8pass4b_VERSION */

#define Comp_2_OA_RES_CTRL_REG            (* (reg32 *) Comp_2_cy_psoc4_abuf__OA_RES_CTRL)
#define Comp_2_OA_RES_CTRL_PTR            (  (reg32 *) Comp_2_cy_psoc4_abuf__OA_RES_CTRL)

#define Comp_2_OA_COMP_STAT_REG           (* (reg32 *) Comp_2_cy_psoc4_abuf__COMP_STAT)
#define Comp_2_OA_COMP_STAT_PTR           (  (reg32 *) Comp_2_cy_psoc4_abuf__COMP_STAT)

#define Comp_2_OA_OFFSET_TRIM_REG         (* (reg32 *) Comp_2_cy_psoc4_abuf__OA_OFFSET_TRIM)
#define Comp_2_OA_OFFSET_TRIM_PTR         (  (reg32 *) Comp_2_cy_psoc4_abuf__OA_OFFSET_TRIM)

#define Comp_2_OA_SLOPE_OFFSET_TRIM_REG   (* (reg32 *) Comp_2_cy_psoc4_abuf__OA_SLOPE_OFFSET_TRIM)
#define Comp_2_OA_SLOPE_OFFSET_TRIM_PTR   (  (reg32 *) Comp_2_cy_psoc4_abuf__OA_SLOPE_OFFSET_TRIM)

#define Comp_2_OA_COMP_SHIFT              (Comp_2_cy_psoc4_abuf__COMP_STAT_SHIFT)

#define Comp_2_INTR_REG       (*(reg32 *)Comp_2_cy_psoc4_abuf__INTR)
#define Comp_2_INTR_PTR       ( (reg32 *)Comp_2_cy_psoc4_abuf__INTR)

#define Comp_2_INTR_SET_REG   (*(reg32 *)Comp_2_cy_psoc4_abuf__INTR_SET)
#define Comp_2_INTR_SET_PTR   ( (reg32 *)Comp_2_cy_psoc4_abuf__INTR_SET)

#define Comp_2_INTR_MASK_REG    (*(reg32 *)Comp_2_cy_psoc4_abuf__INTR_MASK) 
#define Comp_2_INTR_MASK_PTR    ( (reg32 *)Comp_2_cy_psoc4_abuf__INTR_MASK) 

#define Comp_2_INTR_MASKED_REG  (*(reg32 *)Comp_2_cy_psoc4_abuf__INTR_MASKED) 
#define Comp_2_INTR_MASKED_PTR  ( (reg32 *)Comp_2_cy_psoc4_abuf__INTR_MASKED)

/***************************************
*        Registers Constants
***************************************/

/* Comp_2_CTB_CTRL_REG */
#define Comp_2_CTB_CTRL_DEEPSLEEP_ON_SHIFT    (30u)   /* [30] Selects behavior CTB IP in the DeepSleep power mode */
#define Comp_2_CTB_CTRL_ENABLED_SHIFT         (31u)   /* [31] Enable of the CTB IP */

#define Comp_2_CTB_CTRL_DEEPSLEEP_ON          ((uint32) 0x01u << Comp_2_CTB_CTRL_DEEPSLEEP_ON_SHIFT)
#define Comp_2_CTB_CTRL_ENABLED               ((uint32) 0x01u << Comp_2_CTB_CTRL_ENABLED_SHIFT)

/* Comp_2_OA_RES_CTRL_REG */
#define Comp_2_OA_PWR_MODE_SHIFT          (0u)    /* [1:0]    Power level */
#define Comp_2_OA_COMP_EN_SHIFT           (4u)    /* [4]      Comparator enable */
#define Comp_2_OA_HYST_EN_SHIFT           (5u)    /* [5]      Hysteresis enable (10mV) */
#define Comp_2_OA_BYPASS_DSI_SYNC_SHIFT   (6u)    /* [6]      Bypass comparator output synchronization for DSI (trigger) output */
#define Comp_2_OA_COMPINT_SHIFT           (8u)    /* [9:8]    Sets Interrupt mode */
#define Comp_2_OA_PUMP_EN_SHIFT           (11u)   /* [11]     Pump enable */

#define Comp_2_OA_PWR_MODE                ((uint32) 0x02u << Comp_2_OA_PWR_MODE_SHIFT)
#define Comp_2_OA_PWR_MODE_MASK           ((uint32) 0x03u << Comp_2_OA_PWR_MODE_SHIFT)
#define Comp_2_OA_COMP_EN                 ((uint32) 0x01u << Comp_2_OA_COMP_EN_SHIFT)
#define Comp_2_OA_HYST_EN                 ((uint32) 0x01u << Comp_2_OA_HYST_EN_SHIFT)
#define Comp_2_OA_BYPASS_DSI_SYNC         ((uint32) 0x01u << Comp_2_OA_BYPASS_DSI_SYNC_SHIFT)
#define Comp_2_OA_COMPINT_MASK            ((uint32) 0x03u << Comp_2_OA_COMPINT_SHIFT)
#define Comp_2_OA_PUMP_EN                 ((uint32) 0x01u << Comp_2_OA_PUMP_EN_SHIFT)


/***************************************
*       Init Macros Definitions
***************************************/

#define Comp_2_GET_DEEPSLEEP_ON(deepSleep)    ((0u != (deepSleep)) ? (Comp_2_CTB_CTRL_DEEPSLEEP_ON) : (0u))
#define Comp_2_GET_OA_HYST_EN(hyst)           ((0u != (hyst)) ? (Comp_2_OA_HYST_EN) : (0u))
#define Comp_2_GET_OA_PWR_MODE(mode)          ((mode) & Comp_2_OA_PWR_MODE_MASK)
#define Comp_2_CHECK_PWR_MODE_OFF             (0u != (Comp_2_OA_RES_CTRL_REG & \
                                                                Comp_2_OA_PWR_MODE_MASK))
#define Comp_2_GET_OA_COMPINT(intType)        ((uint32) ((((uint32)(intType) << Comp_2_OA_COMPINT_SHIFT)) & \
                                                        Comp_2_OA_COMPINT_MASK))

#define Comp_2_GET_INTR_MASK(mask)            ((0u != (mask)) ? (Comp_2_INTR_MASK) : (0u))

/* Returns true if component available in Deep Sleep power mode*/ 
#define Comp_2_CHECK_DEEPSLEEP_SUPPORT        (0u != Comp_2_DEEPSLEEP_SUPPORT) 

#define Comp_2_DEFAULT_CTB_CTRL (Comp_2_GET_DEEPSLEEP_ON(Comp_2_DEEPSLEEP_SUPPORT) | \
                                           Comp_2_CTB_CTRL_ENABLED)

#define Comp_2_DEFAULT_OA_RES_CTRL (Comp_2_OA_COMP_EN | \
                                              Comp_2_GET_OA_HYST_EN(Comp_2_HYSTERESIS)  | \
                                              Comp_2_GET_OA_COMPINT(Comp_2_INTERRUPT) |\
                                              Comp_2_OA_BYPASS_DSI_SYNC)

#define Comp_2_INTR_MASK_REG_DEFAULT  (Comp_2_GET_INTR_MASK(Comp_2_INTERRUPT_EN))


/***************************************
* The following code is DEPRECATED and 
* should not be used in new projects.
***************************************/

/* Power constants for SetSpeed() function */
#define Comp_2_SLOWSPEED      (Comp_2_SLOW_SPEED)
#define Comp_2_MEDSPEED       (Comp_2_MED_SPEED)
#define Comp_2_HIGHSPEED      (Comp_2_HIGH_SPEED)

#define Comp_2_OA_CTRL_REG        (Comp_2_OA_RES_CTRL_REG)
#define Comp_2_OA_COMPSTAT_REG    (Comp_2_OA_COMP_STAT_REG)
#define Comp_2_OA_COMPSHIFT       (Comp_2_OA_COMP_SHIFT)

#define Comp_2_OA_CTB_EN_SHIFT    (Comp_2_CTB_CTRL_ENABLED_SHIFT)
#define Comp_2_OA_PWR_MODE_HIGH   (Comp_2_HIGH_SPEED) 
#define Comp_2_OA_BYPASS_SHIFT    (Comp_2_OA_BYPASS_DSI_SYNC_SHIFT)

#endif /*  CY_COMPARATOR_Comp_2_H */


/* [] END OF FILE */

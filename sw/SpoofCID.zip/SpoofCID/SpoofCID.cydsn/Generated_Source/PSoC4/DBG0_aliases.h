/*******************************************************************************
* File Name: DBG0.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DBG0_ALIASES_H) /* Pins DBG0_ALIASES_H */
#define CY_PINS_DBG0_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define DBG0_0			(DBG0__0__PC)
#define DBG0_0_PS		(DBG0__0__PS)
#define DBG0_0_PC		(DBG0__0__PC)
#define DBG0_0_DR		(DBG0__0__DR)
#define DBG0_0_SHIFT	(DBG0__0__SHIFT)
#define DBG0_0_INTR	((uint16)((uint16)0x0003u << (DBG0__0__SHIFT*2u)))

#define DBG0_INTR_ALL	 ((uint16)(DBG0_0_INTR))


#endif /* End Pins DBG0_ALIASES_H */


/* [] END OF FILE */

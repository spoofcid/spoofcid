/*******************************************************************************
* File Name: RSP_DET.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_RSP_DET_ALIASES_H) /* Pins RSP_DET_ALIASES_H */
#define CY_PINS_RSP_DET_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define RSP_DET_0			(RSP_DET__0__PC)
#define RSP_DET_0_PS		(RSP_DET__0__PS)
#define RSP_DET_0_PC		(RSP_DET__0__PC)
#define RSP_DET_0_DR		(RSP_DET__0__DR)
#define RSP_DET_0_SHIFT	(RSP_DET__0__SHIFT)
#define RSP_DET_0_INTR	((uint16)((uint16)0x0003u << (RSP_DET__0__SHIFT*2u)))

#define RSP_DET_INTR_ALL	 ((uint16)(RSP_DET_0_INTR))


#endif /* End Pins RSP_DET_ALIASES_H */


/* [] END OF FILE */

/*******************************************************************************
* File Name: SDCMD.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SDCMD_ALIASES_H) /* Pins SDCMD_ALIASES_H */
#define CY_PINS_SDCMD_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define SDCMD_0			(SDCMD__0__PC)
#define SDCMD_0_PS		(SDCMD__0__PS)
#define SDCMD_0_PC		(SDCMD__0__PC)
#define SDCMD_0_DR		(SDCMD__0__DR)
#define SDCMD_0_SHIFT	(SDCMD__0__SHIFT)
#define SDCMD_0_INTR	((uint16)((uint16)0x0003u << (SDCMD__0__SHIFT*2u)))

#define SDCMD_INTR_ALL	 ((uint16)(SDCMD_0_INTR))


#endif /* End Pins SDCMD_ALIASES_H */


/* [] END OF FILE */

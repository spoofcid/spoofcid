/* 
 * This file is part of the SpoofCID https://github.com/spoofcid/spoofcid
 * Copyright (c) 2017 Rick Sanchez - modimo
 * 
 * This program is free software: you can redistribute it and/or modify  
 * it under the terms of the GNU General Public License as published by  
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU 
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License 
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
*/


#include <stdio.h>
#include <string.h>
#include <project.h>
#include "PSoC_FatFs_Library\diskio.h"
#include "PSoC_FatFs_Library\ff.h"
//# define readStatus() CY_GET_REG16(SD_CID_RESPONDER_1_StatusReg__16BIT_STATUS_REG);
# define readStatus() CY_GET_REG8(SD_CID_RESPONDER_1_StatusReg__STATUS_REG);
# define readFifocnt() CY_GET_REG8(SD_CID_RESPONDER_1_fifo_cnt_rd__STATUS_REG);


const unsigned char CRCTable[256]={
    0x00 ,0x09 ,0x12 ,0x1b ,0x24 ,0x2d ,0x36 ,0x3f ,0x48 ,0x41 ,0x5a ,0x53 ,0x6c ,0x65 ,0x7e ,0x77 ,
    0x19 ,0x10 ,0x0b ,0x02 ,0x3d ,0x34 ,0x2f ,0x26 ,0x51 ,0x58 ,0x43 ,0x4a ,0x75 ,0x7c ,0x67 ,0x6e ,
    0x32 ,0x3b ,0x20 ,0x29 ,0x16 ,0x1f ,0x04 ,0x0d ,0x7a ,0x73 ,0x68 ,0x61 ,0x5e ,0x57 ,0x4c ,0x45 ,
    0x2b ,0x22 ,0x39 ,0x30 ,0x0f ,0x06 ,0x1d ,0x14 ,0x63 ,0x6a ,0x71 ,0x78 ,0x47 ,0x4e ,0x55 ,0x5c ,
    0x64 ,0x6d ,0x76 ,0x7f ,0x40 ,0x49 ,0x52 ,0x5b ,0x2c ,0x25 ,0x3e ,0x37 ,0x08 ,0x01 ,0x1a ,0x13 ,
    0x7d ,0x74 ,0x6f ,0x66 ,0x59 ,0x50 ,0x4b ,0x42 ,0x35 ,0x3c ,0x27 ,0x2e ,0x11 ,0x18 ,0x03 ,0x0a ,
    0x56 ,0x5f ,0x44 ,0x4d ,0x72 ,0x7b ,0x60 ,0x69 ,0x1e ,0x17 ,0x0c ,0x05 ,0x3a ,0x33 ,0x28 ,0x21 ,
    0x4f ,0x46 ,0x5d ,0x54 ,0x6b ,0x62 ,0x79 ,0x70 ,0x07 ,0x0e ,0x15 ,0x1c ,0x23 ,0x2a ,0x31 ,0x38 ,
    0x41 ,0x48 ,0x53 ,0x5a ,0x65 ,0x6c ,0x77 ,0x7e ,0x09 ,0x00 ,0x1b ,0x12 ,0x2d ,0x24 ,0x3f ,0x36 ,
    0x58 ,0x51 ,0x4a ,0x43 ,0x7c ,0x75 ,0x6e ,0x67 ,0x10 ,0x19 ,0x02 ,0x0b ,0x34 ,0x3d ,0x26 ,0x2f ,
    0x73 ,0x7a ,0x61 ,0x68 ,0x57 ,0x5e ,0x45 ,0x4c ,0x3b ,0x32 ,0x29 ,0x20 ,0x1f ,0x16 ,0x0d ,0x04 ,
    0x6a ,0x63 ,0x78 ,0x71 ,0x4e ,0x47 ,0x5c ,0x55 ,0x22 ,0x2b ,0x30 ,0x39 ,0x06 ,0x0f ,0x14 ,0x1d ,
    0x25 ,0x2c ,0x37 ,0x3e ,0x01 ,0x08 ,0x13 ,0x1a ,0x6d ,0x64 ,0x7f ,0x76 ,0x49 ,0x40 ,0x5b ,0x52 ,
    0x3c ,0x35 ,0x2e ,0x27 ,0x18 ,0x11 ,0x0a ,0x03 ,0x74 ,0x7d ,0x66 ,0x6f ,0x50 ,0x59 ,0x42 ,0x4b ,
    0x17 ,0x1e ,0x05 ,0x0c ,0x33 ,0x3a ,0x21 ,0x28 ,0x5f ,0x56 ,0x4d ,0x44 ,0x7b ,0x72 ,0x69 ,0x60 ,
    0x0e ,0x07 ,0x1c ,0x15 ,0x2a ,0x23 ,0x38 ,0x31 ,0x46 ,0x4f ,0x54 ,0x5d ,0x62 ,0x6b ,0x70 ,0x79};

// adds a message byte to the current CRC-7 to get a the new CRC-7
unsigned char CRCAdd(unsigned char CRC, unsigned char message_byte)
{
    return CRCTable[(CRC << 1) ^ message_byte];
}


// returns the CRC-7 for a message of "length" bytes
unsigned char getCRC(unsigned char message[], int length)
{
    int i;
    unsigned char CRC = 0;

    for (i = 0; i < length; i++)
        CRC = CRCAdd(CRC, message[i]);

    return CRC<<1|1;;
}
void Test_A();
void FatFsError(FRESULT result);


#define OVERRIDE_EN 1
#define OVERRIDE_CID 2
#define OVERRIDE_CSD 2

static const uint8_t CYCODE config[64] CY_SECTION(".cy_checksum_exclude") = {0u} ;


const uint8_t *cfgver=&config[0];
const uint8_t *card_state=&config[1];
#define CARDS_STATE_DEFULT 0 // do nothing
#define CARDS_STATE_REPLACE_CID 1 // normal operation
#define CARDS_STATE_COPY_CID_ONCE 2 // copy CID from slave and return to normal operation

const uint8_t *eepromCID=&config[48];//48-63 CID

// in bootloader if configure.txt available reconfigure
// if no configure.txt exist write instructions to instructions.txt

void writeInstructions();
void reconfigure();
int8 cnt;
volatile const uint8 * ptr;
int main()
{
    CyGlobalIntEnable;      /* Enable global interrupts */
 
    uint8_t CSD[16];//={0x40,0x0e,0x00,0x32,0x5b,0x59,0x00,0x00,0xef,0x17,0x7f,0x80,0x0a,0x40,0x00,0x59};
    uint8_t CID[16];// ={0x03,0x53,0x44,0x53,0x42,0x31,0x36,0x47,0x80,0x90,0x73,0x49,0x1C,0x01,0x19,0xAF};//={0x03,0x53,0x44,0x53,0x55,0x30,0x32,0x47,0x80,0x02,0x30,0x3e,0x44,0x00,0x92,0xAD};//piodi lark
    //Comp_1_Start();
    
     char msg[10]; 
               //  LED_Write(1);
               // CyDelay(100u);
               // LED_Write(0);
      
           // 
    if(Pin_StartBootloader_Read() == 0u)
    //if(SD_DET_Read() == 0u)
		{
			/* This API will pass the program control to the Bootloader portion 
			   of the flash. It will also cause the Bootloader to wait indefinitely 
			   for the host to start communication */
		//	
		}
         LED_Write(1);
    //CY_SET_REG8( SD_CID_RESPONDER_1_enable__CONTROL_REG,  OVERRIDE_EN);
    //UART_Start();
      if(*cfgver==0){//initialize eeprom
        //UART_UartPutString("\r\nFirst Initialization\r\n");
        uint8_t tmp=0;
        Em_EEPROM_Write(&tmp, card_state, 1u);
        tmp=1;
        Em_EEPROM_Write(&tmp, cfgver, 1u);
        
        ///writeInstructions();
    }else{
        if(*card_state==CARDS_STATE_REPLACE_CID){
            for(int i=0;i<16;++i)
                CID[i]=eepromCID[i];
            CY_SET_REG8( SD_CID_RESPONDER_1_enable__CONTROL_REG,  OVERRIDE_EN|OVERRIDE_CID);            
        }
        else{
            
            CY_SET_REG8( SD_CID_RESPONDER_1_enable__CONTROL_REG,  0);   
        }
        
    }    
    
    //CY_SET_REG8( SD_CID_RESPONDER_1_enable__CONTROL_REG,  OVERRIDE_EN|OVERRIDE_CID);    
 
      //  LED_Write(0);
        if(SD_DET_Read() == 1u)//programming CID
		{
            
            CY_SET_REG8( SD_CID_RESPONDER_1_enable__CONTROL_REG,  0x80);//disconnect sd 
            do{
                LED_Write(1);
                CyDelay(500u);
                LED_Write(0);
                CyDelay(500u);
            }while(SD_DET_Read() == 1u);
 
            CyDelay(1000u);
			SPI_1_Start();//start spi controller
          //  SPI_1_miso_m_SetDriveMode(SPI_1_miso_m_DM_RES_UP);
             (*(reg32 *)SPI_1_ss0_m__0__HSIOM) = 
                    ((*(reg32 *)SPI_1_ss0_m__0__HSIOM) & (uint32)~SPI_1_ss0_m__0__HSIOM_MASK) | (uint32)(SPI_1_HSIOM_GPIO_SEL << SPI_1_ss0_m__0__HSIOM_SHIFT);
            SPI_1_ss0_m_Write(1); 

                    
            //CyDelay(3000u);
 
       //     if(card_state==CARDS_STATE_DEFULT)
            reconfigure();
            writeInstructions();
            LED_Write(1);    
            while(1){
            //Test_A();
                       
            CyDelay(1000u);
            }
		}
    
        
        
  
    

    //UART_UartPutString("Hello World!\n\r");
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    //uint8_t counter;
    uint16_t sta;
    uint8_t waitfor;
    uint8_t wrdata;
    uint8_t done=0;
    
    //SPI_1_Stop();
    
   // CID[15]=getCRC(CID,15);//calcuate crc7
   // CSD[15]=getCRC(CSD,15);//calcuate crc7
    for(;;)
    {   
        //LED_Write(1);
        while(1){
       //     

            
            sta=readStatus();
            if(sta&1){                
              CY_SET_REG8( SD_CID_RESPONDER_1_dataIn__CONTROL_REG,  0xff );
                
                do{
                sta=readStatus();
                }while((sta&0xc)==(0xc));
                  
                do{
                sta=readFifocnt();
                }while((sta&0xff)>0x20);
                waitfor=5;
               
               
                for(uint32_t i=0;i<16;++i){
                    wrdata=CID[i];
                    do{
                    sta=readFifocnt();
                    }while((sta&0xff)<waitfor);
                    CY_SET_REG8( SD_CID_RESPONDER_1_dataIn__CONTROL_REG,  wrdata);
                    waitfor+=0x4;
                    wrdata<<=4;
                    wrdata|=0xf;
                    do{
                    sta=readFifocnt();
                    }while((sta&0xff)<waitfor);
                    CY_SET_REG8( SD_CID_RESPONDER_1_dataIn__CONTROL_REG,  wrdata);
                    waitfor+=0x4;
                }
                do{
                    sta=readFifocnt();
                }while((sta&0xff)<waitfor);
                CY_SET_REG8( SD_CID_RESPONDER_1_dataIn__CONTROL_REG,  0xff);
                done|=1;
                do{
                  sta=readStatus();
                }while((sta&3)!=0);
                CY_SET_REG8( SD_CID_RESPONDER_1_dataIn__CONTROL_REG,  0xff);
                
            }
            if(sta&2&&0){
               CY_SET_REG8( SD_CID_RESPONDER_1_dataIn__CONTROL_REG,  0xff );
                do{
                sta=readStatus();
                }while((sta&0xc)==(0xc));
                
                do{
                sta=readFifocnt();
                }while((sta&0xff)>0x20);
                waitfor=5;
                for(uint32_t i=0;i<16;++i){
                    wrdata=CSD[i];
                    do{
                    sta=readFifocnt();
                    }while((sta&0xff)<waitfor);
                    CY_SET_REG8( SD_CID_RESPONDER_1_dataIn__CONTROL_REG,  wrdata);
                    waitfor+=0x4;
                    wrdata<<=4;
                    wrdata|=0xf;
                    do{
                    sta=readFifocnt();
                    }while((sta&0xff)<waitfor);
                    CY_SET_REG8( SD_CID_RESPONDER_1_dataIn__CONTROL_REG,  wrdata);
                    waitfor+=0x4;
                }
                do{
                    sta=readFifocnt();
                }while((sta&0xff)<waitfor);
                CY_SET_REG8( SD_CID_RESPONDER_1_dataIn__CONTROL_REG,  0xff);
                
                done|=2;
                do{
                  sta=readStatus();
                }while((sta&3)!=0);
            }
            if(done==1){
          //      CY_SET_REG8( SD_CID_RESPONDER_1_enable__CONTROL_REG,  0x00);
                LED_Write(0);
            }
            
            
           // CY_SET_REG8( SD_CID_RESPONDER_1_myControlReg__CONTROL_REG,  counter++ );
        }
       
    }
}
#define C_INSTRUCTIONS_HEADER ("==SpoofCID info==\r\n")

#define C_CARD_VOL_ID "Card volume label: "
#define C_CARD_CID "Card CID: "
#define C_SPOOF_CID "Spoof CID: "
#define C_CARD_CSD "Card CSD: "




void  writeInstructions(){
    FATFS fatFs;
    FIL fileO;
    DIR directoryO;
    FILINFO fileInfo;
    uint8 resultF;
    UINT bw;
    uint8_t CID[16];
    FATFS *fatFsPtr;
    
    char str[100];
    uint32 freeclusters, freesectors, totalsectors;
   // UART_UartPutString("Writting instructions \r\n");
    /* Mount sdcard. */
    resultF = f_mount(&fatFs, "", 1);
    
    if (resultF == RES_OK)
    {

        
        //UART_UartPutString("Create file \r\n");
        resultF = f_open (&fileO,"info.txt",FA_WRITE |FA_CREATE_ALWAYS);
        if (resultF != FR_OK)
        {
            FatFsError(resultF);
            return;
        }
        resultF = f_write(&fileO,C_INSTRUCTIONS_HEADER,sizeof(C_INSTRUCTIONS_HEADER)-1,&bw);
        if (resultF != FR_OK){FatFsError(resultF);return;}
        
        resultF = f_write(&fileO,C_CARD_VOL_ID,sizeof(C_CARD_VOL_ID)-1,&bw);
        if (resultF != FR_OK){FatFsError(resultF);return;}
        
        
        /* read volume label. */
        resultF = f_getlabel("", str, 0);
        
        if (resultF != FR_OK)
        {
            FatFsError(resultF);
            return;
        }

        resultF = f_write(&fileO,str,strlen(str),&bw);
        resultF = f_write(&fileO,"\r\n",2,&bw);
        if (resultF != FR_OK){FatFsError(resultF);return;}
        //////
        
        resultF = f_write(&fileO,C_CARD_CID,sizeof(C_CARD_CID)-1,&bw);
        if (resultF != FR_OK){FatFsError(resultF);return;}
        
        
        disk_ioctl(fatFs.drv,GET_CID,CID);        
        for(uint8_t i=0;i<16;++i)
            sprintf(str+i*2,"%02X",CID[i]);
        sprintf(str+16*2,"\r\n");
        resultF = f_write(&fileO,str,strlen(str),&bw);
        if (resultF != FR_OK){FatFsError(resultF);return;}
        
        
         resultF = f_write(&fileO,C_SPOOF_CID,sizeof(C_SPOOF_CID)-1,&bw);
        if (resultF != FR_OK){FatFsError(resultF);return;}
        
        
              
        for(uint8_t i=0;i<16;++i)
            sprintf(str+i*2,"%02X",eepromCID[i]);
        sprintf(str+16*2,"\r\n");
        resultF = f_write(&fileO,str,strlen(str),&bw);
        if (resultF != FR_OK){FatFsError(resultF);return;}
        
        //////
       /* resultF = f_write(&fileO,C_CARD_CSD,sizeof(C_CARD_CSD)-1,&bw);
        if (resultF != FR_OK){FatFsError(resultF);return;}
        
        
        disk_ioctl(fatFs.drv,GET_CSD,CID);        
        for(uint8_t i=0;i<16;++i)
            sprintf(str+i*2,"%02X",CID[i]);
        sprintf(str+16*2,"\r\n");
        resultF = f_write(&fileO,str,strlen(str),&bw);
        if (resultF != FR_OK){FatFsError(resultF);return;}
        */
        ///
        resultF = f_sync(&fileO);
        if (resultF != FR_OK){FatFsError(resultF);return;}
        
        resultF = f_close(&fileO);
        if (resultF != FR_OK){FatFsError(resultF);return;}
        
      //  UART_UartPutString("Umount \r\n");
        resultF = f_mount(0, "", 0);
        if (resultF != FR_OK){FatFsError(resultF);return;}
               

        return;
    }
}
uint8_t hextodec(char h,char l){
    uint8_t b;
    if(h>='a')
        b=(h-'a'+10)*16;        
    else if(h>='A')
        b=(h-'A'+10)*16; 
    else if(h>='0')
        b=(h-'0')*16;
    if(l>='a')
        b+=(l-'a'+10);        
    else if(l>='A')
        b+=(l-'A'+10); 
    else if(l>='0')
        b+=(l-'0');
    return b;
}
void reconfigure(){
    FATFS fatFs;
    FIL fileI;
    DIR directoryO;
    FILINFO fileInfo;
    uint8 resultF;
    UINT br;
    uint8_t b;
    char buff[129];
    char cmd[129];
    char arg[129];
    FATFS *fatFsPtr;
    
    char str[100];
    uint32 freeclusters, freesectors, totalsectors;
 //   UART_UartPutString("Reconfiguring \r\n");
    /* Mount sdcard. */
    resultF = f_mount(&fatFs, "", 1);
    
    if (resultF == RES_OK)
    {

        
      //  UART_UartPutString("Open config file \r\n");
        resultF = f_open (&fileI,"conf.txt",FA_READ);
        if (resultF != FR_OK)
        {
            FatFsError(resultF);
            return;
        }
        

            resultF = f_read(&fileI,buff,128,&br);
            if (resultF != FR_OK){FatFsError(resultF);return;}
            buff[128]=0;
            
            sscanf(buff,"%s %s",cmd,arg);
            
            cmd[3]=0;
            arg[32]=0;
           //  UART_UartPutString(cmd);
            if(cmd[0]=='L'&&cmd[1]=='D'&&cmd[2]=='R')
                 Bootloadable_Load();
            
            if(cmd[0]=='C'&&cmd[1]=='I'&&cmd[2]=='D'){
                for(int i=0;i<16;++i){
                    b=hextodec(arg[i*2],arg[i*2+1]);    
                    if(i!=15)
                        Em_EEPROM_Write(&b, &eepromCID[i], 1u);
                    
                }              
                b=getCRC(eepromCID,15);       
                Em_EEPROM_Write(&b, &eepromCID[15], 1u);
                b=CARDS_STATE_REPLACE_CID;
                Em_EEPROM_Write(&b, card_state, 1u);
            }
        return;
    }
}

/*
void Test_A()
{
    FATFS fatFs;
    FIL fileO;
    DIR directoryO;
    FILINFO fileInfo;
    uint8 resultF;
    uint8_t CID[16];
    FATFS *fatFsPtr;
    
    char str[100];
    uint32 freeclusters, freesectors, totalsectors;

    resultF = f_mount(&fatFs, "", 1);
    
    if (resultF == RES_OK)
    {
        resultF = f_getlabel("", str, 0);
        
        if (resultF != FR_OK)
        {
            FatFsError(resultF);
            return;
        }

        
        
        
        UART_UartPutString("\n\rVolume label: ");
        UART_UartPutString(str);
        UART_UartPutString("\n\r");
        
        disk_ioctl(fatFs.drv,GET_CID,CID);        
        sprintf(str,"CID: ");
        for(uint8_t i=0;i<16;++i)
            sprintf(str+5+i*2,"%02X",CID[i]);
        sprintf(str+5+16*2,"\r\n");
        UART_UartPutString(str);
        disk_ioctl(fatFs.drv,GET_CSD,CID);
        sprintf(str,"CSD: ");
        for(uint8_t i=0;i<16;++i)
            sprintf(str+5+i*2,"%02X",CID[i]);
        sprintf(str+5+16*2,"\r\n");
        UART_UartPutString(str);
        
        
        UART_UartPutString("\n\r\n\r");
        
        resultF = f_opendir(&directoryO, "/");      // open 'root' directory.
        if (resultF != 0)
        {
            FatFsError(resultF);
            return;
        }
        
        while(1)
        {
            resultF = f_readdir(&directoryO, &fileInfo);
            if (resultF != 0)
            {
                FatFsError(resultF);
                break;
            }
            
            if (fileInfo.fname[0] == 0)             // end of directory?
            {
                break;     
            }
            
            if (fileInfo.fattrib & AM_DIR)          // is it a directory?
            {
                UART_UartPutString(fileInfo.fname);
                UART_UartPutString("\t\t\t<DIR>\n\r");
            }
            else                                    // it is a file.
            {
                UART_UartPutString(fileInfo.fname);
                UART_UartPutString("\t\t\t");     
                
                sprintf(str,"%ld",fileInfo.fsize);
                UART_UartPutString(str);
                UART_UartPutString("\n\r");
            }
                        
        }
  
        totalsectors = (fatFsPtr->n_fatent - 2) * fatFsPtr->csize;
        freesectors = freeclusters * fatFsPtr->csize;  

        itoa(totalsectors, str, 10);
        UART_UartPutString("\n\r\tTotal sectors: "); UART_UartPutString(str); UART_UartPutString("\n\r");
        itoa(freesectors, str, 10);
        UART_UartPutString("\tFree sectors: "); UART_UartPutString(str); UART_UartPutString("\n\r");
        itoa((totalsectors /2), str, 10);
        UART_UartPutString("\tDrive space: "); UART_UartPutString(str); UART_UartPutString("\n\r");
        itoa((freesectors /2), str, 10);
        UART_UartPutString("\tFree space: "); UART_UartPutString(str); UART_UartPutString("\n\r\n\r");        
        
        f_closedir(&directoryO);
        
     /
        resultF = f_mount(NULL, "", 1);
        if (resultF != FR_OK)
        {
            FatFsError(resultF);
            return;
        }
    }
    else FatFsError(resultF);
}
*/

void FatFsError(FRESULT result)
{
  //  UART_UartPutString("Fatfs error\r\n");
    return;
}/*
    switch (result)
    {
        case FR_DISK_ERR:
            UART_UartPutString("\n\r    error: (FR_DISK_ERR) low level error.\n\r"); break;
            
        case FR_INT_ERR:
            UART_UartPutString("\n\r    error: (FR_INT_ERR)\n\r"); break; 
            
        case FR_NOT_READY:
            UART_UartPutString("\n\r    error: (FR_NOT_READY) sdcard not ready.\n\r"); break;
            
        case FR_NO_FILE:
            UART_UartPutString("\n\r    error: (FR_NO_FILE) invalid file.\n\r"); break;
            
        case FR_NO_PATH:
            UART_UartPutString("\n\r    error: (FR_NO_PATH) invalid path.\n\r"); break;
            
        case FR_INVALID_NAME:
            UART_UartPutString("\n\r    error: (FR_INVALID_NAME) invalid name.\n\r"); break;
            
        case FR_DENIED:
            UART_UartPutString("\n\r    error: (FR_DENIED) operation denied.\n\r"); break;
            
        case FR_EXIST:
            UART_UartPutString("\n\r    error: (FR_EXIST) it exists yet...\n\r"); break;
            
        case FR_INVALID_OBJECT:
            UART_UartPutString("\n\r    error: (FR_INVALID_OBJECT)\n\r"); break;
            
        case FR_WRITE_PROTECTED:
            UART_UartPutString("\n\r    error: (FR_WRITE_PROTECTED)\n\r"); break;
            
        case FR_INVALID_DRIVE:
            UART_UartPutString("\n\r    error: (FR_INVALID_DRIVE)\n\r"); break;
            
        case FR_NOT_ENABLED:
            UART_UartPutString("\n\r    error: (FR_NOT_ENABLED) sdcard unmounted.\n\r"); break;
            
        case FR_NO_FILESYSTEM:
            UART_UartPutString("\n\r    error: (FR_NO_FILESYSTEM) no valid FAT volume.\n\r"); break;  
            
        case FR_MKFS_ABORTED:
            UART_UartPutString("\n\r    error: (FR_MKFS_ABORTED)\n\r"); break;
            
        case FR_TIMEOUT:
            UART_UartPutString("\n\r    error: (FR_TIMEOUT)\n\r"); break;
            
        case FR_LOCKED:
            UART_UartPutString("\n\r    error: (FR_LOCKED)\n\r"); break;
            
        case FR_NOT_ENOUGH_CORE:
            UART_UartPutString("\n\r    error: (FR_NOT_ENOUGH_CORE)\n\r"); break;     
            
        case FR_TOO_MANY_OPEN_FILES:
            UART_UartPutString("\n\r    error: (FR_TOO_MANY_OPEN_FILES)\n\r"); break;
            
        case FR_INVALID_PARAMETER:
            UART_UartPutString("\n\r    error: (FR_INVALID_PARAMETER)\n\r"); break; 
            
        default: {}; break;
    }
}*/


